/*
 * Classe abstrata que representa qualquer produto do sistema.
 * Ela nao pode ser instanciada diretamente, apenas herdada por outras classes.
 */
public abstract class Produto {

    protected int codigo;
    protected String nome;
    protected double preco;

    // Construtor usado pelas subclasses. Ele ja valida se o preco e valido.
    public Produto(int codigo, String nome, double preco) throws PrecoInvalidoException {
        if (preco <= 0) {
            throw new PrecoInvalidoException("O preco deve ser maior que zero.");
        }

        this.codigo = codigo;
        this.nome = nome;
        this.preco = preco;
    }

    // Metodo abstrato: cada tipo de produto calcula o preco final do seu jeito.
    public abstract double calcularPrecoFinal();

    // Sobrecarga: calcula o preco final aplicando desconto.
    public double calcularPrecoFinal(double percentualDesconto) throws PrecoInvalidoException {
        if (percentualDesconto < 0) {
            throw new PrecoInvalidoException("O desconto nao pode ser negativo.");
        }
        if (percentualDesconto > 50) {
            throw new PrecoInvalidoException("O desconto nao pode ser maior que 50%.");
        }

        double precoBase = calcularPrecoFinal();
        return precoBase - (precoBase * percentualDesconto / 100);
    }

    // Sobrecarga: calcula o preco final com desconto e frete.
    public double calcularPrecoFinal(double percentualDesconto, double frete) throws PrecoInvalidoException {
        if (frete < 0) {
            throw new PrecoInvalidoException("O frete nao pode ser negativo.");
        }

        return calcularPrecoFinal(percentualDesconto) + frete;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    // O setter tambem valida o preco, para nao permitir alteracao invalida.
    public void setPreco(double preco) throws PrecoInvalidoException {
        if (preco <= 0) {
            throw new PrecoInvalidoException("O preco deve ser maior que zero.");
        }
        this.preco = preco;
    }

    // Define como o produto sera exibido quando usar System.out.println(produto).
    @Override
    public String toString() {
        return String.format("Codigo: %d | Nome: %s | Tipo: %s | Preco: R$ %.2f | Preco final: R$ %.2f",
                codigo, nome, getClass().getSimpleName(), preco, calcularPrecoFinal());
    }
}
