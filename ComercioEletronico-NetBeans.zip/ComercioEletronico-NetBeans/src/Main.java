// Questão 2 - Miguel Lucas Luna de Souza Silva e Davi Brito Barros 
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Classe principal do sistema.
 * Aqui ficam o menu, a lista de produtos e as operacoes feitas pelo usuario.
 */
public class Main {

    // Lista em memoria: os produtos ficam salvos enquanto o programa estiver aberto.
    static ArrayList<Produto> produtos = new ArrayList<>();

    // Scanner usado para ler tudo que o usuario digita no terminal.
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao;

        // O menu fica repetindo ate o usuario escolher a opcao 0.
        do {
            menu();
            opcao = lerInt("Escolha uma opcao: ");

            switch (opcao) {
                case 1 -> cadastrar();
                case 2 -> alterar();
                case 3 -> excluir();
                case 4 -> mostrarProduto(selecionarPorCodigo());
                case 5 -> buscarPorNome();
                case 6 -> listar();
                case 7 -> vender();
                case 0 -> System.out.println("Encerrando o sistema...");
                default -> System.out.println("Opcao invalida!");
            }
        } while (opcao != 0);
    }

    // Mostra as opcoes disponiveis no sistema.
    static void menu() {
        System.out.println("\n=== SISTEMA DE COMERCIO ELETRONICO ===");
        System.out.println("1 - Cadastrar produto");
        System.out.println("2 - Alterar produto");
        System.out.println("3 - Excluir produto");
        System.out.println("4 - Buscar produto por codigo");
        System.out.println("5 - Buscar produto por nome");
        System.out.println("6 - Listar todos os produtos");
        System.out.println("7 - Realizar venda");
        System.out.println("0 - Sair");
    }

    // Cadastra um produto novo na lista.
    static void cadastrar() {
        System.out.println("\n-- Cadastro de produto --");
        System.out.println("Tipos: 1-Smartphone | 2-Notebook | 3-Tablet");

        int tipo = lerTipo();
        if (tipo == 0) return;

        int codigo = lerInt("Codigo: ");

        // Impede dois produtos com o mesmo codigo.
        if (buscarPorCodigo(codigo) != null) {
            System.out.println("Ja existe produto com esse codigo.");
            return;
        }

        System.out.print("Nome do produto: ");
        String nome = sc.nextLine();
        if (nome.isBlank()) {
            System.out.println("O nome nao pode ficar em branco.");
            return;
        }

        try {
            Produto novoProduto = criarProduto(tipo, codigo, nome, lerDouble("Preco: "));
            produtos.add(novoProduto);
            System.out.println("Produto cadastrado com sucesso!");
        } catch (PrecoInvalidoException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    // Cria o objeto correto de acordo com o tipo escolhido pelo usuario.
    static Produto criarProduto(int tipo, int codigo, String nome, double preco) throws PrecoInvalidoException {
        return switch (tipo) {
            case 1 -> new Smartphone(codigo, nome, preco);
            case 2 -> new Notebook(codigo, nome, preco);
            case 3 -> new Tablet(codigo, nome, preco);
            default -> null;
        };
    }

    // Permite escolher o tipo pelo numero ou pelo nome.
    static int lerTipo() {
        System.out.print("Tipo do produto: ");
        String tipo = sc.nextLine().trim().toLowerCase();

        int opcao = switch (tipo) {
            case "1", "smartphone", "celular" -> 1;
            case "2", "notebook" -> 2;
            case "3", "tablet" -> 3;
            default -> 0;
        };

        if (opcao == 0) System.out.println("Tipo invalido.");
        return opcao;
    }

    // Altera nome e/ou preco de um produto ja cadastrado.
    static void alterar() {
        Produto p = selecionarProduto("\nCodigo do produto a alterar (0 para buscar por nome): ");
        if (p == null) return;

        System.out.print("Novo nome (Enter para manter): ");
        String nome = sc.nextLine();
        if (!nome.isBlank()) p.setNome(nome);

        double preco = lerDouble("Novo preco (0 para manter): ");
        if (preco > 0) {
            try {
                p.setPreco(preco);
            } catch (PrecoInvalidoException e) {
                System.out.println("Erro: " + e.getMessage());
                return;
            }
        }

        System.out.println("Produto atualizado.");
    }

    // Remove um produto da lista.
    static void excluir() {
        Produto p = selecionarProduto("\nCodigo do produto a excluir (0 para buscar por nome): ");

        if (p != null) {
            produtos.remove(p);
            System.out.println("Produto excluido.");
        }
    }

    // Busca produtos usando o nome ou parte dele.
    static void buscarPorNome() {
        ArrayList<Produto> encontrados = pesquisarPorNome();

        if (encontrados.isEmpty()) {
            System.out.println("Nenhum produto encontrado.");
            return;
        }

        encontrados.forEach(System.out::println);
    }

    // Seleciona um produto pelo codigo. Se o codigo for 0, busca pelo nome.
    static Produto selecionarProduto(String mensagem) {
        int codigo = lerInt(mensagem);
        Produto p = codigo == 0 ? escolherPorNome() : buscarPorCodigo(codigo);

        if (p == null) System.out.println("Produto nao encontrado.");
        return p;
    }

    // Atalho usado pela opcao "buscar por codigo".
    static Produto selecionarPorCodigo() {
        return selecionarProduto("\nCodigo do produto: ");
    }

    // Mostra os produtos encontrados por nome e deixa o usuario escolher pelo codigo.
    static Produto escolherPorNome() {
        ArrayList<Produto> encontrados = pesquisarPorNome();
        if (encontrados.isEmpty()) return null;

        encontrados.forEach(System.out::println);
        return buscarPorCodigo(lerInt("Digite o codigo escolhido: "));
    }

    // Retorna todos os produtos cujo nome contem o texto digitado.
    static ArrayList<Produto> pesquisarPorNome() {
        System.out.print("Nome ou parte do nome: ");
        String texto = sc.nextLine().toLowerCase();
        ArrayList<Produto> encontrados = new ArrayList<>();

        for (Produto p : produtos) {
            if (p.getNome().toLowerCase().contains(texto)) encontrados.add(p);
        }

        return encontrados;
    }

    // Lista todos os produtos cadastrados.
    static void listar() {
        System.out.println("\n-- Lista de produtos --");

        if (produtos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
            return;
        }

        produtos.forEach(System.out::println);
    }

    // Mostra os dados de um produto e, se ele tiver garantia, mostra o valor dela.
    static void mostrarProduto(Produto p) {
        if (p == null) return;

        System.out.println(p);

        // instanceof verifica se o produto implementa a interface Garantia.
        if (p instanceof Garantia g) {
            System.out.printf("Garantia estendida de 12 meses: R$ %.2f%n", g.calcularGarantiaEstendida(12));
        }
    }

    // Realiza uma venda, somando preco final, frete, desconto e garantia estendida.
    static void vender() {
        System.out.println("\n-- Realizar venda --");

        if (produtos.isEmpty()) {
            System.out.println("Cadastre um produto antes de vender.");
            return;
        }

        listar();
        Produto p = selecionarProduto("Codigo do produto vendido: ");
        if (p == null) return;

        int quantidade = lerInt("Quantidade: ");
        if (quantidade <= 0) {
            System.out.println("Quantidade invalida.");
            return;
        }

        try {
            double desconto = lerDouble("Desconto em %: ");
            double frete = lerDouble("Frete: ");
            int mesesGarantia = lerInt("Meses de garantia estendida (0 se nao quiser): ");

            double garantia = valorGarantia(p, mesesGarantia);
            double total = (p.calcularPrecoFinal(desconto, frete) + garantia) * quantidade;

            System.out.println("\nVenda realizada!");
            System.out.println("Produto: " + p.getNome());
            System.out.printf("Garantia por unidade: R$ %.2f%n", garantia);
            System.out.printf("Total da venda: R$ %.2f%n", total);
        } catch (PrecoInvalidoException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    // Calcula a garantia se o produto implementar a interface Garantia.
    static double valorGarantia(Produto p, int meses) {
        if (meses <= 0 || !(p instanceof Garantia g)) return 0;
        return g.calcularGarantiaEstendida(meses);
    }

    // Procura um produto pelo codigo.
    static Produto buscarPorCodigo(int codigo) {
        for (Produto p : produtos) {
            if (p.getCodigo() == codigo) return p;
        }
        return null;
    }

    // Le um numero inteiro e evita erro se o usuario digitar texto.
    static int lerInt(String mensagem) {
        System.out.print(mensagem);

        while (!sc.hasNextInt()) {
            System.out.print("Digite um numero valido: ");
            sc.next();
        }

        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }

    // Le um numero decimal e evita erro se o usuario digitar texto.
    static double lerDouble(String mensagem) {
        System.out.print(mensagem);

        while (!sc.hasNextDouble()) {
            System.out.print("Digite um valor valido: ");
            sc.next();
        }

        double valor = sc.nextDouble();
        sc.nextLine();
        return valor;
    }
}
