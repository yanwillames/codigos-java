/*
 * Tablet herda de ProdutoEletronico e implementa Garantia.
 */
public class Tablet extends ProdutoEletronico implements Garantia {

    public Tablet(int codigo, String nome, double preco) throws PrecoInvalidoException {
        // Tablet tem 12 meses de garantia padrao.
        super(codigo, nome, preco, 12);
    }

    // Polimorfismo: tablets possuem uma regra propria de acrescimo.
    @Override
    public double calcularPrecoFinal() {
        return super.calcularPrecoFinal() * 1.015;
    }

    // Cada mes extra de garantia para tablet custa R$ 18,00.
    @Override
    public double calcularGarantiaEstendida(int meses) {
        return meses * 18.0;
    }
}
