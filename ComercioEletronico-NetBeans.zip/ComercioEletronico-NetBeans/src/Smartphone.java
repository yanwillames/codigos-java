/*
 * Smartphone herda de ProdutoEletronico e implementa Garantia.
 * Isso significa que ele tem preco final proprio e garantia estendida.
 */
public class Smartphone extends ProdutoEletronico implements Garantia {

    public Smartphone(int codigo, String nome, double preco) throws PrecoInvalidoException {
        // Smartphone tem 12 meses de garantia padrao.
        super(codigo, nome, preco, 12);
    }

    // Polimorfismo: sobrescreve o calculo do preco final para smartphone.
    @Override
    public double calcularPrecoFinal() {
        return super.calcularPrecoFinal() * 1.03;
    }

    // Cada mes extra de garantia para smartphone custa R$ 15,00.
    @Override
    public double calcularGarantiaEstendida(int meses) {
        return meses * 15.0;
    }
}
