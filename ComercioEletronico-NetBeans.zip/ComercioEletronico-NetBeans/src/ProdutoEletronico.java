/*
 * Classe intermediaria da heranca.
 * Todo ProdutoEletronico tambem e um Produto, mas possui garantia padrao.
 */
public abstract class ProdutoEletronico extends Produto {

    protected int mesesGarantiaPadrao;

    public ProdutoEletronico(int codigo, String nome, double preco, int mesesGarantiaPadrao) throws PrecoInvalidoException {
        // Chama o construtor da classe Produto.
        super(codigo, nome, preco);
        this.mesesGarantiaPadrao = mesesGarantiaPadrao;
    }

    // Regra geral: todo eletronico tem 5% de acrescimo no preco.
    @Override
    public double calcularPrecoFinal() {
        return preco * 1.05;
    }
}
