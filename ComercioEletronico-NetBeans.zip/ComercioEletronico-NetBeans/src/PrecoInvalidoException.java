/*
 * Excecao personalizada para erros de regra de negocio.
 * Ela e usada quando preco, desconto ou frete possuem valores invalidos.
 */
public class PrecoInvalidoException extends Exception {

    public PrecoInvalidoException(String mensagem) {
        // Envia a mensagem de erro para a classe Exception.
        super(mensagem);
    }
}
