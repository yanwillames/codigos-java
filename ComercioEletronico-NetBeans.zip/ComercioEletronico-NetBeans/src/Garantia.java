/*
 * Interface usada como contrato para produtos que possuem garantia estendida.
 * Quem implementa Garantia precisa criar o metodo calcularGarantiaEstendida.
 */
public interface Garantia {

    // Calcula o valor da garantia de acordo com a quantidade de meses extras.
    double calcularGarantiaEstendida(int meses);
}
