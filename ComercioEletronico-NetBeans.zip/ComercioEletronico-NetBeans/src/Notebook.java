/*
 * Notebook herda de ProdutoEletronico e implementa Garantia.
 */
public class Notebook extends ProdutoEletronico implements Garantia {

    public Notebook(int codigo, String nome, double preco) throws PrecoInvalidoException {
        // Notebook tem 24 meses de garantia padrao.
        super(codigo, nome, preco, 24);
    }

    // Polimorfismo: notebooks possuem uma regra propria de acrescimo.
    @Override
    public double calcularPrecoFinal() {
        return super.calcularPrecoFinal() * 1.02;
    }

    // Cada mes extra de garantia para notebook custa R$ 25,00.
    @Override
    public double calcularGarantiaEstendida(int meses) {
        return meses * 25.0;
    }
}
