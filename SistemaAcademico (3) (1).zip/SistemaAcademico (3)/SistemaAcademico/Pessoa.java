// Classe Pessoa
// É a classe base do sistema.
// Todas as outras classes herdarão dela.

public class Pessoa {

    // Atributos da classe
    protected String nome;
    protected String cpf;

    // Construtor
    public Pessoa(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }

    // Métodos Gets
    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    // Métodos Sets
    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

}