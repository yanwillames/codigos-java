// Declara a classe Pessoa, que representa uma pessoa comum no sistema.
// Essa classe sera a classe pai de Funcionario.
public class Pessoa {

    // Guarda o nome da pessoa.
    // O private impede que esse atributo seja acessado diretamente fora da classe.
    private String nome;

    // Guarda o CPF da pessoa.
    private String cpf;

    // Guarda a idade da pessoa.
    private int idade;

    // Construtor da classe Pessoa.
    // Ele recebe os valores iniciais de nome, cpf e idade.
    public Pessoa(String nome, String cpf, int idade) {

        // this.nome representa o atributo da classe.
        // nome representa o parametro recebido no construtor.
        this.nome = nome;

        // Armazena o CPF recebido no atributo cpf.
        this.cpf = cpf;

        // Armazena a idade recebida no atributo idade.
        this.idade = idade;
    }

    // Metodo getNome.
    // Serve para consultar o nome da pessoa.
    public String getNome() {

        // Retorna o valor guardado no atributo nome.
        return nome;
    }

    // Metodo setNome.
    // Serve para alterar o nome da pessoa.
    public void setNome(String nome) {

        // Atualiza o atributo nome com o novo valor recebido.
        this.nome = nome;
    }

    // Metodo getCpf.
    // Serve para consultar o CPF da pessoa.
    public String getCpf() {

        // Retorna o valor guardado no atributo cpf.
        return cpf;
    }

    // Metodo setCpf.
    // Serve para alterar o CPF da pessoa.
    public void setCpf(String cpf) {

        // Atualiza o atributo cpf com o novo valor recebido.
        this.cpf = cpf;
    }

    // Metodo getIdade.
    // Serve para consultar a idade da pessoa.
    public int getIdade() {

        // Retorna o valor guardado no atributo idade.
        return idade;
    }

    // Metodo setIdade.
    // Serve para alterar a idade da pessoa.
    public void setIdade(int idade) {

        // Atualiza o atributo idade com o novo valor recebido.
        this.idade = idade;
    }
}
